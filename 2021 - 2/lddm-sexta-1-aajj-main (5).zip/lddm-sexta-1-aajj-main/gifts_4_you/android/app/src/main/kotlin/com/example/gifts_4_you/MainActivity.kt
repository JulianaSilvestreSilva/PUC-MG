package com.example.gifts_4_you

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
